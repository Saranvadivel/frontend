import axios from 'axios';

const API_URL = `${window.location.origin}/api`;

export const registerUser = async (email, password) => {
  try {
    return await axios.post(`${API_URL}/auth/register`, { email, password });
  } catch (error) {
    // console.error('Error registering user:', error.response ? error.response.data : error.message);
    throw error; 
  }
};

export const loginUser = async (email, password) => {
  try {
    const response = await axios.post(`${API_URL}/auth/login`, { email, password });
    localStorage.setItem('token', response.data.token); // Store JWT token in local storage
    return response;
  } catch (error) {
    // console.error('Error logging in:', error.response ? error.response.data : error.message);
    throw error; // Rethrow to handle it in the component
  }
};

export const sendEmail = async (emailData) => {
  const formData = new FormData();
  Object.keys(emailData).forEach((key) => formData.append(key, emailData[key]));

  try {
    return await axios.post(`${API_URL}/emails/send`, formData, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`, // Include token in the request headers
        'Content-Type': 'multipart/form-data',
      },
    });
  } catch (error) {
    // console.error('Error sending email:', error.response ? error.response.data : error.message);
    throw error; // Rethrow to handle it in the component
  }
};

export const getEmails = async () => {
  try {
    return await axios.get(`${API_URL}/emails`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
  } catch (error) {
    // console.error('Error retrieving emails:', error.response ? error.response.data : error.message);
    throw error; // Rethrow to handle it in the component
  }
};

export const logoutUser = () => {
  localStorage.removeItem('token');
};
