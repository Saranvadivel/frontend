import React, { useState } from 'react';
import { sendEmail } from '../services/api';

const EmailForm = ({ from }) => {
  const [to, setTo] = useState('');
  const [cc, setCc] = useState('');
  const [bcc, setBcc] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
   const emailData = {
  from,
  to: to.split(',').map(email => email.trim()),
  cc: cc.split(',').map(email => email.trim()),
  bcc: bcc.split(',').map(email => email.trim()),
  subject,
  message: body 
};
  

   

    try {
      await sendEmail(emailData);
      setTo('');
      setCc('');
      setBcc('');
      setSubject('');
      setBody('');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>From:</label>
        <input type="email" value={from} readOnly />
      </div>
      <div>
        <label>To:</label>
        <input
          type="text"
          value={to}
          onChange={(e) => setTo(e.target.value)}
          placeholder="recipient1@example.com, recipient2@example.com"
          required
        />
      </div>
      <div>
        <label>CC:</label>
        <input
          type="text"
          value={cc}
          onChange={(e) => setCc(e.target.value)}
          placeholder="cc1@example.com, cc2@example.com"
        />
      </div>
      <div>
        <label>BCC:</label>
        <input
          type="text"
          value={bcc}
          onChange={(e) => setBcc(e.target.value)}
          placeholder="bcc1@example.com, bcc2@example.com"
        />
      </div>
      <div>
        <label>Subject:</label>
        <input
          type="text"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          required
        />
      </div>
      <div>
        <label>Body:</label>
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          required
        />
      </div>
      <button type="submit">Send Email</button>
      {error && <p>{error}</p>}
    </form>
  );
};

export default EmailForm;
