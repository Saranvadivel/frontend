import React from 'react'

export default function Bin() {
  return (
    <div>
      <p>Bin</p>
    </div>
  )
}
