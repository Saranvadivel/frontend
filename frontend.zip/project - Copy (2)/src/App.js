import React, { useState } from 'react';
import Auth from './components/Auth';
import EmailForm from './components/EmailForm';
import Inbox from './components/Inbox';
import SentEmail from './components/SentEmail';

const App = () => {
  const [userEmail, setUserEmail] = useState('');

  return (
    <div>
      <h1>Email Application</h1>
      <Auth setUserEmail={setUserEmail} />
      {userEmail && (
        <>
          <EmailForm from={userEmail} />
          <Inbox />
          <SentEmail userEmail={userEmail} /> 
        </>
      )}
    </div>
  );
};

export default App;
